package com.example.chady;

import android.app.Activity;

public class RecyclerActivity extends Activity {

}
