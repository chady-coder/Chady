package com.example.chady

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        startActivity(LocaliserActivity2.getStartIntent(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        /*Handler(Looper.getMainLooper()).postDelayed({
            startActivity(MainActivity.getStartIntent(this))
            finish()
        }, 1000)*/
        findViewById<Button>(R.id.clique_ici).setOnClickListener{
            /* MaterialDialog(this).show {
                 title(text = "bienvenue")
                 message(text = "non")
                 positiveButton(text = "Pas cool")
                 negativeButton(text = "cool")
             }*/
            MaterialAlertDialogBuilder(this)
                .setTitle(resources.getString(R.string.title))
                .setMessage(resources.getString(R.string.supporting_text))
                .setNeutralButton(resources.getString(R.string.cancel)) { dialog, which ->
                    Snackbar.make(findViewById(android.R.id.content), "Accepte par pitié !!!", Snackbar.LENGTH_LONG).setAction("J'accepte"){
                        Toast.makeText(this,"bien joué", Toast.LENGTH_LONG).show()
                    }
                }
                .setNegativeButton(resources.getString(R.string.decline)) { dialog, which ->
                    startActivity(MainActivity.getStartIntent(this))

                }
                .setPositiveButton(resources.getString(R.string.accept)) { dialog, which ->
                    Toast.makeText(this,"bien joué", Toast.LENGTH_LONG).show()
                }
                .show()
        }
    }


}